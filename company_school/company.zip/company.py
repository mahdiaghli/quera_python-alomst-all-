from work_place import *


class Company(WorkPlace):
    def __init__(self, name):
        self.expertise = "copmany"
        super().__init__(name)

    def calc_capacity(self):
        self.capacity = self.level

    def calc_costs(self):
        costs = Consts.BASE_PLACE_COST * self.level
        return costs

