from work_place import *
from math import *


class Mine(WorkPlace):
    def __init__(self, name):
        self.expertise = "mine"
        super().__init__(name)

    def calc_capacity(self):
        self.capacity = pow(self.level, 2)

    def calc_costs(self):
        costs = Consts.BASE_PLACE_COST + Consts.LEVEL_MUL * self.level
        return costs
